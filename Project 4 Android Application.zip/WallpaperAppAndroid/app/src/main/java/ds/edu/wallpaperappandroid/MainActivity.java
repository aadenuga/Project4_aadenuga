package ds.edu.wallpaperappandroid;

import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    MainActivity me = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final MainActivity ma = this;

        Button submitButton = findViewById(R.id.searchButton);
        Button setWallpaperButton = (Button) findViewById(R.id.setWallpaperButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View viewParam) {
                String searchTerm = ((EditText) findViewById(R.id.searchTerm)).getText().toString();
                System.out.println("searchTerm = " + searchTerm);
                GetWallpaper gw = new GetWallpaper();
                gw.search(searchTerm, me, ma);
            }
        });

        setWallpaperButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setWallpaper();
            }
        });
    }

    public void wallpaperReady(Bitmap picture) {
        ImageView pictureView = (ImageView) findViewById(R.id.wallpaperImage);
        TextView searchView = (EditText) findViewById(R.id.searchTerm);
        TextView feedbackView = (TextView) findViewById(R.id.feedback);
        Button setWallpaperButton = (Button) findViewById(R.id.setWallpaperButton);

        if (picture != null) {
            String feedbackMessage = "Here's a wallpaper for: " + searchView.getText().toString();
            feedbackView.setText(feedbackMessage);
            pictureView.setImageBitmap(picture);
            System.out.println("Wallpaper loaded");
            pictureView.setVisibility(View.VISIBLE);
            setWallpaperButton.setEnabled(true);
        } else {
            String feedbackMessage = "Sorry, could not find a wallpaper for: " + searchView.getText().toString();
            feedbackView.setText(feedbackMessage);
            pictureView.setImageResource(R.mipmap.ic_launcher);
            System.out.println("No wallpaper found");
            pictureView.setVisibility(View.INVISIBLE);
            setWallpaperButton.setEnabled(false);
        }
        searchView.setText("");
        pictureView.invalidate();
    }

    private void setWallpaper() {
        WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
        ImageView pictureView = findViewById(R.id.wallpaperImage);
        Drawable drawable = pictureView.getDrawable();

        if (drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            try {
                wallpaperManager.setBitmap(bitmap);
                Toast.makeText(this, "Wallpaper set successfully", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                Toast.makeText(this, "Error setting wallpaper", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }
}