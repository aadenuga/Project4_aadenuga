package ds.edu.wallpaperappandroid;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class GetWallpaper {

    private static final String SERVLET_URL = "https://redesigned-memory-xqgw5j7pjvqc9p6v-8080.app.github.dev";

    private MainActivity ip = null;
    private String searchTerm = null;

    public void search(String searchTerm, Activity activity, MainActivity ip) {
        this.ip = ip;
        this.searchTerm = searchTerm;
        startBackgroundTask(activity);
    }

    private void startBackgroundTask(Activity activity) {
        new Thread(() -> {
            Bitmap picture = doInBackground(); // Fetch the picture in background
            activity.runOnUiThread(() -> onPostExecute(picture)); // Update UI on main thread
        }).start();
    }

    private Bitmap doInBackground() {
        return search(searchTerm);
    }

    public void onPostExecute(Bitmap picture) {
        ip.wallpaperReady(picture); // Notify main activity with the picture
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private Bitmap search(String searchTerm) {
        try {
            String encodedQuery = URLEncoder.encode(searchTerm, "UTF-8");
            URL url = new URL(SERVLET_URL + "?query=" + encodedQuery);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();

            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                Log.e("GetWallpaper", "HTTP error code: " + responseCode);
                return null; // Return null if response is not OK
            }

            // Read response
            StringBuilder response = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            }

            Log.d("GetWallpaper", "Received response: " + response.toString());

            // Parse JSON response
            JSONObject jsonResponse = new JSONObject(response.toString());
            if (jsonResponse.has("imageUrl")) {
                String imageUrl = jsonResponse.getString("imageUrl");
                Log.d("GetWallpaper", "Image URL: " + imageUrl);
                return downloadImage(imageUrl); // Download and decode the image
            } else {
                Log.e("GetWallpaper", "No image URL found in response.");
            }
        } catch (Exception e) {
            Log.e("GetWallpaper", "Error fetching image: " + e.getMessage());
        }
        return null; // Return null if any exception occurs
    }

    private Bitmap downloadImage(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();

            InputStream inputStream = connection.getInputStream();

            // Decode bitmap from input stream directly
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            if (bitmap == null) {
                Log.e("GetWallpaper", "Failed to decode bitmap from input stream.");
            }

            inputStream.close(); // Close the input stream after use

            return bitmap; // Return the decoded bitmap
        } catch (IOException e) {
            Log.e("GetWallpaper", "Error downloading image: " + e.getMessage());
        }
        return null; // Return null if any exception occurs
    }
}