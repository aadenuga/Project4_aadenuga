package ds.edu.wallpaper;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.*;

/**
 * Author: Mitun Adenuga (aadenuga)
 * Last Modified: November 20, 2024
 *
 * This program is the servlet class that leads to two
 * endpoints for my project 4 assignment. The getWallpaper
 * endpoint is the main functionality of the app which
 * fetches an image from the Unsplash API based on a key term
 * inputted by the user. Secondly, the dashboard API
 * logs useful information about the requests and responses and is
 * connected to  MongoDB database that saves all of this information.
 */

@WebServlet(urlPatterns = {"/getWallpaper", "/dashboard"})
public class WallpaperServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(WallpaperServlet.class.getName());
    private static final String UNSPLASH_API_URL = "https://api.unsplash.com/search/photos";
    private static final String ACCESS_KEY = "LjDYQ8huTk6Armb3lymWrLpT7eEATIoENDnScu_StVs";

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> logsCollection;

    @Override
    public void init() throws ServletException {
        super.init();
        String connectionString = "mongodb://aadenuga:wW7hDVVdHmvxm48p@cluster0-shard-00-02.1eqyc.mongodb.net:27017,cluster0-shard-00-01.1eqyc.mongodb.net:27017,cluster0-shard-00-00.1eqyc.mongodb.net:27017/myFirstDatabase?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        try {
            mongoClient = MongoClients.create(connectionString);
            database = mongoClient.getDatabase("myFirstDatabase");
            logsCollection = database.getCollection("request_logs");
            LOGGER.info("MongoDB connection initialized");
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to initialize MongoDB connection", e);
            throw new ServletException("Failed to initialize MongoDB connection", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String servletPath = request.getServletPath();

        if ("/getWallpaper".equals(servletPath)) {
            handleGetWallpaper(request, response);
        } else if ("/dashboard".equals(servletPath)) {
            handleDashboard(request, response);
        }
    }

    private void handleGetWallpaper(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        long startTime = System.currentTimeMillis();
        Document logEntry = new Document("timestamp", new Date())
                .append("clientIp", request.getRemoteAddr())
                .append("userAgent", request.getHeader("User-Agent"));

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String query = request.getParameter("query");
        logEntry.append("query", query);
        LOGGER.info("Search query: " + query);

        if (query == null || query.trim().isEmpty()) {
            sendErrorResponse(response, out, HttpServletResponse.SC_BAD_REQUEST, "Query parameter is required");
            logEntry.append("status", "BAD_REQUEST").append("errorMessage", "Empty query");
            logsCollection.insertOne(logEntry);
            return;
        }

        try {
            String encodedQuery = URLEncoder.encode(query, "UTF-8");
            URL url = new URL(UNSPLASH_API_URL + "?query=" + encodedQuery + "&client_id=" + ACCESS_KEY);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new IOException("HTTP error code: " + responseCode);
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder content = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            conn.disconnect();

            JSONObject jsonResponse = new JSONObject(content.toString());
            JSONArray results = jsonResponse.getJSONArray("results");

            if (results.length() > 0) {
                JSONObject firstImage = results.getJSONObject(0);
                String imageUrl = firstImage.getJSONObject("urls").getString("regular");

                JSONObject responseJson = new JSONObject();
                responseJson.put("imageUrl", imageUrl);
                out.print(responseJson.toString());

                logEntry.append("status", "SUCCESS").append("imageUrl", imageUrl);
            } else {
                sendErrorResponse(response, out, HttpServletResponse.SC_NOT_FOUND, "No images found");
                logEntry.append("status", "NO_RESULTS");
            }
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Network error", e);
            sendErrorResponse(response, out, HttpServletResponse.SC_BAD_GATEWAY, "Error connecting to image service");
            logEntry.append("status", "NETWORK_ERROR").append("errorMessage", e.getMessage());
        } catch (JSONException e) {
            LOGGER.log(Level.SEVERE, "JSON parsing error", e);
            sendErrorResponse(response, out, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error processing image data");
            logEntry.append("status", "JSON_ERROR").append("errorMessage", e.getMessage());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error", e);
            sendErrorResponse(response, out, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal server error");
            logEntry.append("status", "ERROR").append("errorMessage", e.getMessage());
        } finally {
            long endTime = System.currentTimeMillis();
            logEntry.append("processingTime", endTime - startTime);
            logsCollection.insertOne(logEntry);
        }
    }

    private void sendErrorResponse(HttpServletResponse response, PrintWriter out, int statusCode, String message) throws IOException {
        response.setStatus(statusCode);
        out.print(new JSONObject().put("error", message).toString());
    }

    private void handleDashboard(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            JsonObject analytics = getAnalytics();
            JsonArray logs = getRecentLogs(10);

            JsonObject dashboardData = new JsonObject();
            dashboardData.add("analytics", analytics);
            dashboardData.add("logs", logs);

            out.print(new Gson().toJson(dashboardData));
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error processing dashboard request", e);
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(new JSONObject().put("error", "Error loading analytics").toString());
        }
    }

    private JsonObject getAnalytics() {
        JsonObject analytics = new JsonObject();
        analytics.addProperty("totalRequests", logsCollection.countDocuments());
        analytics.addProperty("successfulRequests", logsCollection.countDocuments(new Document("status", "SUCCESS")));

        // Top 5 search queries
        List<Document> topQueries = logsCollection.aggregate(Arrays.asList(
                new Document("$group", new Document("_id", "$query").append("count", new Document("$sum", 1))),
                new Document("$sort", new Document("count", -1)),
                new Document("$limit", 5)
        )).into(new ArrayList<>());

        JsonArray topQueriesJson = new JsonArray();
        for (Document doc : topQueries) {
            JsonObject queryObj = new JsonObject();
            queryObj.addProperty("query", doc.getString("_id"));
            queryObj.addProperty("count", doc.getInteger("count"));
            topQueriesJson.add(queryObj);
        }
        analytics.add("topQueries", topQueriesJson);

        return analytics;
    }

    private JsonArray getRecentLogs(int limit) {
        JsonArray logsArray = new JsonArray();
        for (Document log : logsCollection.find().sort(new Document("timestamp", -1)).limit(limit)) {
            JsonObject logJson = new JsonObject();
            logJson.addProperty("timestamp", log.getDate("timestamp").toString());
            logJson.addProperty("query", log.getString("query"));
            logJson.addProperty("status", log.getString("status"));
            logJson.addProperty("processingTime", log.getLong("processingTime"));
            logsArray.add(logJson);
        }
        return logsArray;
    }

    @Override
    public void destroy() {
        if (mongoClient != null) {
            mongoClient.close();
            LOGGER.info("MongoDB connection closed");
        }
        super.destroy();
    }
}
